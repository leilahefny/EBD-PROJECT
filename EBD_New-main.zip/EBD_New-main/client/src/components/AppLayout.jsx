import { useState, useEffect } from "react";
import { NavLink, Outlet } from "react-router-dom";
import Footer from "./Footer";
import Navigation from "./Navigation";
import NotificationCenter from "./NotificationCenter";
import { useAuth } from "../context/AuthContext.jsx";
import { fetchNotifications } from "../services/api.js";

const navLinks = [
  { to: '/', label: 'Home' },
  { to: '/dashboard', label: 'Dashboard' },
  { to: '/gam3yas', label: 'Gam3yas' },
  { to: '/positions', label: 'Positions' },
  { to: '/login', label: 'Login' },
]

function AppLayout() {
  const { user, logout } = useAuth();
  const [showNotifications, setShowNotifications] = useState(false);
  const [unreadCount, setUnreadCount] = useState(0);

  useEffect(() => {
    if (user) {
      const loadNotifications = async () => {
        try {
          const data = await fetchNotifications(user._id);
          setUnreadCount(data.unreadCount || 0);
        } catch (err) {
          // Silent fail
        }
      };
      loadNotifications();
      const interval = setInterval(loadNotifications, 30000); // Refresh every 30s
      return () => clearInterval(interval);
    }
  }, [user]);

  return (
    <div className="app-shell">
      <header className="glass" style={{ position: 'sticky', top: 0, zIndex: 10 }}>
        <div className="container">
          <div className="flex between" style={{ padding: '14px 0' }}>
            <NavLink to="/" style={{ fontWeight: 800, fontSize: 18 }}>
              Gama3li Shokran
            </NavLink>
            <div className="flex" style={{ gap: 16, alignItems: "center" }}>
              <Navigation
                links={[
                  ...navLinks,
                  ...(user?.role === "admin" ? [{ to: "/admin", label: "Admin" }] : []),
                ]}
              />
              {user && (
                <div className="flex" style={{ gap: 8, alignItems: "center" }}>
                  <button
                    type="button"
                    className="btn secondary"
                    onClick={() => setShowNotifications(true)}
                    style={{
                      paddingInline: 12,
                      position: "relative",
                    }}
                    title="Notifications"
                  >
                    🔔
                    {unreadCount > 0 && (
                      <span
                        style={{
                          position: "absolute",
                          top: -4,
                          right: -4,
                          background: "#ef4444",
                          color: "white",
                          borderRadius: "50%",
                          width: 20,
                          height: 20,
                          display: "flex",
                          alignItems: "center",
                          justifyContent: "center",
                          fontSize: "0.75rem",
                          fontWeight: "bold",
                        }}
                      >
                        {unreadCount > 9 ? "9+" : unreadCount}
                      </span>
                    )}
                  </button>
                  <span className="pill">
                    Hi, {user.username}
                    {user.role === "admin" ? " (admin)" : ""}
                  </span>
                  <button
                    type="button"
                    className="btn secondary"
                    onClick={logout}
                    style={{ paddingInline: 12 }}
                  >
                    Logout
                  </button>
                </div>
              )}
            </div>
          </div>
        </div>
      </header>

      <main className="container" style={{ flex: 1, width: 'min(1150px,92vw)' }}>
        <Outlet />
      </main>

      <Footer />
      {user && (
        <NotificationCenter
          isOpen={showNotifications}
          onClose={() => {
            setShowNotifications(false);
            // Refresh unread count when closing
            if (user) {
              fetchNotifications(user._id)
                .then((data) => setUnreadCount(data.unreadCount || 0))
                .catch(() => {});
            }
          }}
        />
      )}
    </div>
  )
}

export default AppLayout

