import { NavLink } from 'react-router-dom'

function Navigation({ links }) {
  return (
    <nav className="flex" style={{ gap: 10 }}>
      {links.map((link) => (
        <NavLink
          key={link.to}
          to={link.to}
          className={({ isActive }) =>
            [
              'pill',
              isActive ? 'active-link' : '',
            ]
              .join(' ')
              .trim()
          }
          style={({ isActive }) =>
            isActive
              ? { background: '#e0e7ff', color: '#312e81', fontWeight: 700 }
              : undefined
          }
        >
          {link.label}
        </NavLink>
      ))}
    </nav>
  )
}

export default Navigation

