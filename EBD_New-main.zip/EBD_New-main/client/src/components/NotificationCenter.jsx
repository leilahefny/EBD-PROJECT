import { useEffect, useState } from "react";
import { useAuth } from "../context/AuthContext.jsx";
import {
  fetchNotifications,
  markNotificationRead,
  markAllNotificationsRead,
  deleteNotification,
} from "../services/api.js";

function NotificationCenter({ isOpen, onClose }) {
  const { user } = useAuth();
  const [notifications, setNotifications] = useState([]);
  const [unreadCount, setUnreadCount] = useState(0);
  const [loading, setLoading] = useState(true);

  const load = async () => {
    if (!user) return;
    try {
      const data = await fetchNotifications(user._id);
      setNotifications(data.notifications || []);
      setUnreadCount(data.unreadCount || 0);
    } catch (err) {
      console.error("Failed to load notifications", err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (isOpen && user) {
      load();
    }
  }, [isOpen, user]);

  const handleMarkRead = async (notificationId) => {
    if (!user) return;
    try {
      await markNotificationRead(notificationId, user._id);
      await load();
    } catch (err) {
      console.error("Failed to mark as read", err);
    }
  };

  const handleMarkAllRead = async () => {
    if (!user) return;
    try {
      await markAllNotificationsRead(user._id);
      await load();
    } catch (err) {
      console.error("Failed to mark all as read", err);
    }
  };

  const handleDelete = async (notificationId) => {
    if (!user) return;
    try {
      await deleteNotification(notificationId, user._id);
      await load();
    } catch (err) {
      console.error("Failed to delete notification", err);
    }
  };

  if (!isOpen) return null;

  return (
    <div
      style={{
        position: "fixed",
        top: 0,
        left: 0,
        right: 0,
        bottom: 0,
        background: "rgba(0,0,0,0.5)",
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
        zIndex: 1000,
      }}
      onClick={onClose}
    >
      <div
        className="card"
        style={{
          maxWidth: 600,
          width: "90%",
          maxHeight: "80vh",
          overflow: "auto",
          zIndex: 1001,
        }}
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex between" style={{ marginBottom: 16 }}>
          <h3 style={{ margin: 0 }}>Notifications {unreadCount > 0 && `(${unreadCount})`}</h3>
          <div className="flex" style={{ gap: 8 }}>
            {unreadCount > 0 && (
              <button className="btn secondary" type="button" onClick={handleMarkAllRead}>
                Mark all read
              </button>
            )}
            <button className="btn secondary" type="button" onClick={onClose}>
              Close
            </button>
          </div>
        </div>

        {loading ? (
          <p className="muted">Loading notifications...</p>
        ) : notifications.length === 0 ? (
          <p className="muted">No notifications</p>
        ) : (
          <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
            {notifications.map((notif) => (
              <div
                key={notif._id}
                style={{
                  padding: 12,
                  background: notif.isRead ? "#f9fafb" : "#eff6ff",
                  borderRadius: 8,
                  border: notif.isRead ? "1px solid #e5e7eb" : "1px solid #3b82f6",
                }}
              >
                <div className="flex between">
                  <div style={{ flex: 1 }}>
                    <p style={{ margin: 0, fontWeight: notif.isRead ? 400 : 600 }}>
                      {notif.title}
                    </p>
                    <p className="muted" style={{ margin: "4px 0 0 0", fontSize: "0.875rem" }}>
                      {notif.message}
                    </p>
                    <p className="muted" style={{ margin: "4px 0 0 0", fontSize: "0.75rem" }}>
                      {new Date(notif.createdAt).toLocaleString()}
                    </p>
                  </div>
                  <div className="flex" style={{ gap: 4, alignItems: "flex-start" }}>
                    {!notif.isRead && (
                      <button
                        className="btn secondary"
                        type="button"
                        onClick={() => handleMarkRead(notif._id)}
                        style={{ fontSize: "0.75rem", padding: "4px 8px" }}
                      >
                        Mark read
                      </button>
                    )}
                    <button
                      className="btn secondary"
                      type="button"
                      onClick={() => handleDelete(notif._id)}
                      style={{ fontSize: "0.75rem", padding: "4px 8px", color: "#b91c1c" }}
                    >
                      Delete
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}

export default NotificationCenter;

