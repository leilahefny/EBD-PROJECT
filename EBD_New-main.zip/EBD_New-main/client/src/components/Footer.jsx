function Footer() {
  return (
    <footer className="section">
      <div className="container flex between" style={{ borderTop: '1px solid #e2e8f0', paddingTop: 16 }}>
        <div>
          <div style={{ fontWeight: 700 }}>Gama3li Shokran</div>
          <p className="muted" style={{ margin: '4px 0 0' }}>
            Digital rotating savings with a fair position marketplace.
          </p>
        </div>
        <div className="muted">Winter 2025 • EBD Project</div>
      </div>
    </footer>
  )
}

export default Footer

