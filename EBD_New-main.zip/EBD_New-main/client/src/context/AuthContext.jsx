import { createContext, useContext, useEffect, useState } from "react";
import { loginUser as apiLoginUser, registerUser as apiRegisterUser } from "../services/api";

const AuthContext = createContext(null);

export function AuthProvider({ children }) {
  const [user, setUser] = useState(null);

  useEffect(() => {
    const stored = localStorage.getItem("gama3li_user");
    if (stored) {
      try {
        setUser(JSON.parse(stored));
      } catch {
        localStorage.removeItem("gama3li_user");
      }
    }
  }, []);

  const login = async (email, password) => {
    const data = await apiLoginUser({ email, password });
    // Avoid storing password hash on the client
    const safeUser = {
      _id: data.user._id,
      username: data.user.username,
      email: data.user.email,
      role: data.user.role,
      creditScore: data.user.creditScore,
      status: data.user.status,
    };
    setUser(safeUser);
    localStorage.setItem("gama3li_user", JSON.stringify(safeUser));
    return safeUser;
  };

  const register = async (username, email, password) => {
    const data = await apiRegisterUser({ username, email, password });
    const safeUser = {
      _id: data.user._id,
      username: data.user.username,
      email: data.user.email,
      role: data.user.role,
      creditScore: data.user.creditScore,
      status: data.user.status,
    };
    setUser(safeUser);
    localStorage.setItem("gama3li_user", JSON.stringify(safeUser));
    return safeUser;
  };

  const logout = () => {
    setUser(null);
    localStorage.removeItem("gama3li_user");
  };

  return (
    <AuthContext.Provider value={{ user, login, register, logout }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const ctx = useContext(AuthContext);
  if (!ctx) {
    throw new Error("useAuth must be used within AuthProvider");
  }
  return ctx;
}


