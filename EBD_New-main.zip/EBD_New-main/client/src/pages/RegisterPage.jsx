import { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { useAuth } from "../context/AuthContext.jsx";

function RegisterPage() {
  const { register } = useAuth();
  const navigate = useNavigate();
  const [form, setForm] = useState({ username: "", email: "", password: "" });
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  const handleChange = (e) => {
    setForm((prev) => ({ ...prev, [e.target.name]: e.target.value }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError("");
    setLoading(true);
    try {
      await register(form.username, form.email, form.password);
      navigate("/dashboard");
    } catch (err) {
      setError(err.message || "Registration failed");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="section" style={{ maxWidth: 520, margin: "0 auto" }}>
      <div className="card">
        <div className="badge">Create account</div>
        <h1 style={{ marginBottom: 6 }}>Sign up</h1>
        <p className="muted" style={{ marginTop: 0 }}>
          Passwords are securely hashed on the server using bcrypt.
        </p>

        {error && (
          <div className="pill" style={{ background: "#fee2e2", color: "#b91c1c", marginBottom: 10 }}>
            {error}
          </div>
        )}

        <form className="grid" style={{ gap: 14, marginTop: 16 }} onSubmit={handleSubmit}>
          <label className="grid" style={{ gap: 6 }}>
            Username
            <input
              name="username"
              value={form.username}
              onChange={handleChange}
              placeholder="yourname"
              required
              style={{
                padding: 12,
                borderRadius: 10,
                border: "1px solid #e2e8f0",
                fontSize: 15,
              }}
            />
          </label>

          <label className="grid" style={{ gap: 6 }}>
            Email
            <input
              type="email"
              name="email"
              value={form.email}
              onChange={handleChange}
              placeholder="you@example.com"
              required
              style={{
                padding: 12,
                borderRadius: 10,
                border: "1px solid #e2e8f0",
                fontSize: 15,
              }}
            />
          </label>

          <label className="grid" style={{ gap: 6 }}>
            Password
            <input
              type="password"
              name="password"
              value={form.password}
              onChange={handleChange}
              placeholder="••••••••"
              minLength={6}
              required
              style={{
                padding: 12,
                borderRadius: 10,
                border: "1px solid #e2e8f0",
                fontSize: 15,
              }}
            />
          </label>

          <button type="submit" className="btn primary" disabled={loading}>
            {loading ? "Creating account..." : "Sign up"}
          </button>
        </form>

        <p className="muted" style={{ marginTop: 12 }}>
          Already have an account? <Link to="/login">Log in</Link>
        </p>
      </div>
    </div>
  );
}

export default RegisterPage;


