import { useEffect, useMemo, useState } from "react";
import { useAuth } from "../context/AuthContext.jsx";
import { fetchGam3yas, fetchPositions, markPositionPaid } from "../services/api.js";

function DashboardPage() {
  const { user } = useAuth();
  const [positions, setPositions] = useState([]);
  const [gam3yas, setGam3yas] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  useEffect(() => {
    const load = async () => {
      if (!user) {
        setLoading(false);
        return;
      }
      try {
        const [posRes, gamRes] = await Promise.all([fetchPositions(), fetchGam3yas()]);
        setPositions(posRes.positions || []);
        setGam3yas(gamRes.gam3yas || []);
      } catch (err) {
        setError(err.message || "Failed to load dashboard data");
      } finally {
        setLoading(false);
      }
    };
    load();
  }, [user]);

  const myPositions = useMemo(
    () => positions.filter((p) => p.userId?._id === user?._id),
    [positions, user]
  );

  const primaryPosition = myPositions[0];
  const primaryGam3ya = gam3yas.find((g) => g._id === primaryPosition?.gam3yaId?._id);

  const handleMarkPaid = async (positionId) => {
    try {
      const res = await markPositionPaid(positionId);
      setPositions((prev) => prev.map((p) => (p._id === positionId ? res.position : p)));
    } catch (err) {
      alert(err.message || "Failed to mark as paid");
    }
  };

  return (
    <div className="section">
      <div className="flex between" style={{ marginBottom: 20 }}>
        <div>
          <div className="badge">Member dashboard</div>
          <h1 style={{ margin: '8px 0 0' }}>Overview</h1>
          <p className="muted">
            Live snapshot of your Gam3ya activity powered by the Express + MongoDB API.
          </p>
        </div>
        <div className="pill" style={{ background: '#e0f2fe', color: '#0f172a' }}>
          {user ? `Logged in as ${user.email}` : "Log in to see your data"}
        </div>
      </div>

      {loading && <p className="muted">Loading dashboard…</p>}
      {error && (
        <p className="muted" style={{ color: "#b91c1c" }}>
          {error}
        </p>
      )}

      <div className="grid cols-3">
        <div className="card">
          <p className="muted">This month contribution</p>
          <h2 style={{ margin: "6px 0" }}>
            {primaryGam3ya ? `${primaryGam3ya.monthlyAmount} EGP` : "—"}
          </h2>
          <p className="muted">
            {primaryGam3ya ? `Gam3ya: ${primaryGam3ya.name}` : "Join a Gam3ya to get started."}
          </p>
        </div>
        <div className="card">
          <p className="muted">Your payout slot</p>
          <h2 style={{ margin: "6px 0" }}>
            {primaryPosition ? `#${primaryPosition.positionNumber}` : "No position yet"}
          </h2>
          <p className="muted">
            {primaryPosition
              ? primaryPosition.isForTrade
                ? "Currently listed for trade."
                : "Not listed for trade."
              : "Generate payout order for a Gam3ya you joined."}
          </p>
        </div>
        <div className="card">
          <p className="muted">Trust score</p>
          <h2 style={{ margin: "6px 0" }}>
            {myPositions.length > 0 ? "Good standing" : "New member"}
          </h2>
          <p className="muted">Improves as you keep up with monthly payments.</p>
        </div>
      </div>

      <div className="card" style={{ marginTop: 20 }}>
        <div className="flex between" style={{ marginBottom: 6 }}>
          <h3 style={{ margin: 0 }}>Recent activity</h3>
          <div className="pill">Based on your positions</div>
        </div>
        {myPositions.length === 0 ? (
          <p className="muted">No activity yet. Join a Gam3ya to start.</p>
        ) : (
          <ul style={{ margin: 0, paddingLeft: 16 }}>
            {myPositions.map((pos) => (
              <li key={pos._id} style={{ marginBottom: 10 }}>
                <strong>
                  Position #{pos.positionNumber} in {pos.gam3yaId?.name || "Gam3ya"}
                </strong>
                <div className="muted">
                  Payment status: {pos.paidThisMonth ? "Paid" : "Not paid"}
                </div>
                {!pos.paidThisMonth && (
                  <button
                    type="button"
                    className="btn secondary"
                    style={{ marginTop: 6, paddingInline: 12 }}
                    onClick={() => handleMarkPaid(pos._id)}
                  >
                    Mark this month as paid
                  </button>
                )}
              </li>
            ))}
          </ul>
        )}
      </div>
    </div>
  )
}

export default DashboardPage

