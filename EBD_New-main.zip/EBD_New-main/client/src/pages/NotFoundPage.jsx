import { Link } from 'react-router-dom'

function NotFoundPage() {
  return (
    <div className="section" style={{ textAlign: 'center' }}>
      <div className="badge">404</div>
      <h1>Page not found</h1>
      <p className="muted">
        This is a static milestone build, so only the listed routes are wired up.
      </p>
      <Link to="/" className="btn primary">
        Back to home
      </Link>
    </div>
  )
}

export default NotFoundPage

