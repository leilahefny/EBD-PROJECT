import { useEffect, useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { useAuth } from "../context/AuthContext.jsx";
import { createGam3ya, fetchGam3yas, generatePayoutOrder, joinGam3ya, getGam3yaById } from "../services/api.js";

function Gam3yaListPage() {
  const { user } = useAuth();
  const navigate = useNavigate();
  const [gam3yas, setGam3yas] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [form, setForm] = useState({ name: "", monthlyAmount: "", maxMembers: "", startDate: "" });
  const [showJoinModal, setShowJoinModal] = useState(false);
  const [selectedGam3ya, setSelectedGam3ya] = useState(null);

  useEffect(() => {
    const load = async () => {
      try {
        const data = await fetchGam3yas();
        setGam3yas(data.gam3yas || []);
      } catch (err) {
        setError(err.message || "Failed to load gam3yas");
      } finally {
        setLoading(false);
      }
    };
    load();
  }, []);

  const handleCreate = async (e) => {
    e.preventDefault();
    if (!user) {
      alert("Please log in first.");
      return;
    }
    try {
      const payload = {
        name: form.name,
        monthlyAmount: Number(form.monthlyAmount),
        maxMembers: Number(form.maxMembers),
        members: [user._id],
        startDate: form.startDate ? new Date(form.startDate) : new Date(),
        status: "open",
      };
      const data = await createGam3ya(payload);
      setGam3yas((prev) => [...prev, data.gam3ya]);
      setForm({ name: "", monthlyAmount: "", maxMembers: "", startDate: "" });
      alert("Gam3ya created successfully!");
    } catch (err) {
      alert(err.message || "Failed to create gam3ya");
    }
  };

  const handleJoinClick = async (gam3ya) => {
    if (!user) {
      alert("Please log in first.");
      return;
    }
    // Check if already member
    const isMember = gam3ya.members?.some((m) => (m._id || m) === user._id);
    if (isMember) {
      alert("You are already a member of this Gam3ya.");
      return;
    }
    // Load full details
    try {
      const details = await getGam3yaById(gam3ya._id);
      setSelectedGam3ya(details.gam3ya);
      setShowJoinModal(true);
    } catch (err) {
      alert("Failed to load Gam3ya details. " + err.message);
    }
  };

  const handleJoinConfirm = async () => {
    if (!user || !selectedGam3ya) return;
    try {
      const data = await joinGam3ya(selectedGam3ya._id, user._id);
      setGam3yas((prev) => prev.map((g) => (g._id === selectedGam3ya._id ? data.gam3ya : g)));
      setShowJoinModal(false);
      setSelectedGam3ya(null);
      alert("Successfully joined Gam3ya!");
    } catch (err) {
      alert(err.message || "Failed to join gam3ya");
    }
  };

  const handleGenerate = async (gam3yaId) => {
    try {
      await generatePayoutOrder(gam3yaId);
      alert("Payout order generated for this Gam3ya.");
    } catch (err) {
      alert(err.message || "Failed to generate payout order");
    }
  };

  return (
    <div className="section">
      <div className="flex between" style={{ marginBottom: 16 }}>
        <div>
          <div className="badge">Browse groups</div>
          <h1 style={{ margin: '8px 0' }}>Gam3yas available</h1>
          <p className="muted">Data is loaded live from the Express + MongoDB API.</p>
        </div>
        <Link to="/dashboard" className="btn secondary">
          Go to dashboard
        </Link>
      </div>

      <div className="card" style={{ marginBottom: 18 }}>
        <h3 style={{ marginTop: 0 }}>Create new Gam3ya</h3>
        {!user && (
          <p className="muted">You must be logged in to create a Gam3ya.</p>
        )}
        <form className="grid" style={{ gap: 10, marginTop: 10 }} onSubmit={handleCreate}>
          <div className="flex" style={{ gap: 10 }}>
            <input
              placeholder="Name"
              value={form.name}
              onChange={(e) => setForm((f) => ({ ...f, name: e.target.value }))}
              required
              style={{ flex: 1, padding: 10, borderRadius: 10, border: "1px solid #e2e8f0" }}
            />
            <input
              type="number"
              placeholder="Monthly amount"
              value={form.monthlyAmount}
              onChange={(e) => setForm((f) => ({ ...f, monthlyAmount: e.target.value }))}
              required
              style={{ width: 150, padding: 10, borderRadius: 10, border: "1px solid #e2e8f0" }}
            />
            <input
              type="number"
              placeholder="Max members"
              value={form.maxMembers}
              onChange={(e) => setForm((f) => ({ ...f, maxMembers: e.target.value }))}
              required
              style={{ width: 130, padding: 10, borderRadius: 10, border: "1px solid #e2e8f0" }}
            />
            <input
              type="date"
              placeholder="Start date"
              value={form.startDate}
              onChange={(e) => setForm((f) => ({ ...f, startDate: e.target.value }))}
              style={{ width: 150, padding: 10, borderRadius: 10, border: "1px solid #e2e8f0" }}
            />
          </div>
          <button type="submit" className="btn primary" disabled={!user}>
            {user ? "Create Gam3ya" : "Login to create"}
          </button>
        </form>
      </div>

      {loading && <p className="muted">Loading gam3yas…</p>}
      {error && (
        <p className="muted" style={{ color: "#b91c1c" }}>
          {error}
        </p>
      )}

      <div className="grid cols-3">
        {gam3yas.map((gam3ya) => {
          const isMember = user && gam3ya.members?.some((m) => (m._id || m) === user._id);
          const isFull = (gam3ya.members?.length || 0) >= gam3ya.maxMembers;
          const isStarted = gam3ya.status === "ongoing" || gam3ya.status === "completed";
          const canJoin = !isFull && !isStarted && !isMember;

          const statusColors = {
            open: { bg: "#eef2ff", color: "#312e81" },
            ongoing: { bg: "#fef3c7", color: "#92400e" },
            completed: { bg: "#d1fae5", color: "#065f46" },
          };

          return (
            <article key={gam3ya._id || gam3ya.id} className="card">
              <div className="flex between">
                <h3 style={{ margin: 0 }}>{gam3ya.name}</h3>
                <span
                  className="pill"
                  style={{
                    background: statusColors[gam3ya.status]?.bg || "#e5e7eb",
                    color: statusColors[gam3ya.status]?.color || "#374151",
                  }}
                >
                  {gam3ya.status?.toUpperCase() || "OPEN"}
                </span>
              </div>
              <p className="muted">Monthly amount: {gam3ya.monthlyAmount} EGP</p>
              <p className="muted">Members: {gam3ya.members?.length || 0} / {gam3ya.maxMembers}</p>
              {gam3ya.startDate && (
                <p className="muted" style={{ fontSize: "0.875rem" }}>
                  Start: {new Date(gam3ya.startDate).toLocaleDateString()}
                </p>
              )}
              <div className="flex" style={{ marginTop: 10, gap: 8, flexWrap: "wrap" }}>
                <Link
                  to={`/gam3yas/${gam3ya._id}`}
                  className="btn secondary"
                  style={{ textDecoration: "none", display: "inline-block" }}
                >
                  View Details
                </Link>
                {canJoin && (
                  <button
                    className="btn primary"
                    type="button"
                    onClick={() => handleJoinClick(gam3ya)}
                  >
                    Join
                  </button>
                )}
                {isMember && gam3ya.status === "open" && !isFull && (
                  <button
                    className="btn secondary"
                    type="button"
                    onClick={() => handleGenerate(gam3ya._id)}
                  >
                    Generate payout order
                  </button>
                )}
                {isFull && !isStarted && (
                  <span className="muted" style={{ fontSize: "0.875rem" }}>
                    Full - Ready to start
                  </span>
                )}
                {isStarted && (
                  <span className="muted" style={{ fontSize: "0.875rem" }}>
                    Already started
                  </span>
                )}
              </div>
            </article>
          );
        })}
      </div>

      {showJoinModal && selectedGam3ya && (
        <div
          style={{
            position: "fixed",
            top: 0,
            left: 0,
            right: 0,
            bottom: 0,
            background: "rgba(0,0,0,0.5)",
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            zIndex: 1000,
          }}
          onClick={() => setShowJoinModal(false)}
        >
          <div
            className="card"
            style={{ maxWidth: 500, width: "90%", zIndex: 1001 }}
            onClick={(e) => e.stopPropagation()}
          >
            <h3 style={{ margin: "0 0 16px 0" }}>Confirm Join Gam3ya</h3>
            <p><strong>Name:</strong> {selectedGam3ya.name}</p>
            <p><strong>Monthly Amount:</strong> {selectedGam3ya.monthlyAmount} EGP</p>
            <p><strong>Members:</strong> {selectedGam3ya.members?.length || 0} / {selectedGam3ya.maxMembers}</p>
            {selectedGam3ya.startDate && (
              <p><strong>Start Date:</strong> {new Date(selectedGam3ya.startDate).toLocaleDateString()}</p>
            )}
            <p className="muted" style={{ marginTop: 16 }}>
              By joining, you agree to make monthly payments of {selectedGam3ya.monthlyAmount} EGP.
            </p>
            <div style={{ display: "flex", gap: 8, marginTop: 16 }}>
              <button className="btn primary" type="button" onClick={handleJoinConfirm}>
                Confirm Join
              </button>
              <button className="btn secondary" type="button" onClick={() => setShowJoinModal(false)}>
                Cancel
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}

export default Gam3yaListPage

