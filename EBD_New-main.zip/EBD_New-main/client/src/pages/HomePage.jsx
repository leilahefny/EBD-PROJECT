import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { fetchGam3yas, fetchTradePositions } from "../services/api.js";

function HomePage() {
  const [gam3yas, setGam3yas] = useState([]);
  const [positions, setPositions] = useState([]);

  useEffect(() => {
    const load = async () => {
      try {
        const [g, p] = await Promise.all([fetchGam3yas(), fetchTradePositions()]);
        setGam3yas(g.gam3yas || []);
        setPositions(p.positions || []);
      } catch {
        // Silent fail for landing page; detailed errors are on inner pages
      }
    };
    load();
  }, []);

  const heroHighlights = [
    "Create or join trusted Gam3ya groups",
    "Trade payout positions when plans change",
    "Track monthly payments with transparency",
  ];

  const featureGrid = [
    {
      title: "Create or Join Gam3ya",
      detail: "Spin up a group in seconds or join an existing circle with clear terms.",
    },
    {
      title: "Auto Payout Order",
      detail: "Generate the payout sequence transparently when the group is full.",
    },
    {
      title: "Payment Tracking",
      detail: "Mark monthly contributions as paid for each payout position.",
    },
    {
      title: "Position Marketplace",
      detail: "List, buy, or swap payout positions when plans change.",
    },
    {
      title: "Trust & History",
      detail: "Build credibility through consistent payments and trading history.",
    },
    {
      title: "Mobile-Friendly",
      detail: "Clean, responsive UI tailored for quick actions on the go.",
    },
  ];

  const featuredGam3yas = gam3yas.slice(0, 3);

  return (
    <div>
      <section className="section">
        <div className="glass" style={{ padding: 28 }}>
          <div className="flex between">
            <div style={{ maxWidth: 520 }}>
              <div className="badge">Milestone 2: Static UI</div>
              <h1 style={{ fontSize: 38, margin: '12px 0 8px' }}>
                A transparent way to run your Gam3ya and trade payout positions.
              </h1>
              <p className="muted" style={{ marginBottom: 16 }}>
                Build, join, and manage rotating savings circles with built-in payment tracking,
                auto-generated payout orders, and a marketplace to swap positions when plans change.
              </p>
              <div className="flex" style={{ gap: 10, flexWrap: 'wrap' }}>
                <Link to="/dashboard" className="btn primary">
                  View Dashboard
                </Link>
                <Link to="/gam3yas" className="btn secondary">
                  Explore Gam3yas
                </Link>
              </div>
            </div>
            <div className="card" style={{ width: 320 }}>
              <h3>Why members like it</h3>
              <ul style={{ paddingLeft: 18, margin: '12px 0' }}>
                {heroHighlights.map((item) => (
                  <li key={item} style={{ marginBottom: 8 }}>
                    {item}
                  </li>
                ))}
              </ul>
              <div className="pill" style={{ background: '#dcfce7', color: '#14532d', fontWeight: 700 }}>
                Trust score & history baked in
              </div>
            </div>
          </div>
        </div>
      </section>

      <section className="section">
        <div className="flex between" style={{ marginBottom: 12 }}>
          <h2 style={{ margin: 0 }}>Featured Gam3yas</h2>
          <Link to="/gam3yas" className="btn secondary">
            See all
          </Link>
        </div>
        <div className="grid cols-3">
          {featuredGam3yas.map((gam3ya) => (
            <article key={gam3ya.id} className="card">
              <h3>{gam3ya.name}</h3>
              <p className="muted">Monthly: {gam3ya.monthlyAmount} EGP</p>
              <div className="pill">Members {gam3ya.filled} / {gam3ya.maxMembers}</div>
              <p style={{ marginTop: 12, fontWeight: 600 }}>Next payout: {gam3ya.nextPayout}</p>
            </article>
          ))}
        </div>
      </section>

      <section className="section">
        <h2 style={{ marginTop: 0 }}>What you can do</h2>
        <div className="grid cols-3">
          {featureGrid.map((feature) => (
            <article key={feature.title} className="card">
              <h3>{feature.title}</h3>
              <p className="muted">{feature.detail}</p>
            </article>
          ))}
        </div>
      </section>
    </div>
  )
}

export default HomePage

