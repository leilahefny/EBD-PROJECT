import { useEffect, useState } from "react";
import { useAuth } from "../context/AuthContext.jsx";
import {
  fetchPositions,
  fetchTradePositions,
  listPositionForTrade,
  createTradeRequest,
  getTradeRequests,
  acceptTradeRequest,
  rejectTradeRequest,
} from "../services/api.js";

function PositionsPage() {
  const { user } = useAuth();
  const [tradePositions, setTradePositions] = useState([]);
  const [myPositions, setMyPositions] = useState([]);
  const [tradeRequests, setTradeRequests] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [activeTab, setActiveTab] = useState("marketplace"); // marketplace, my-requests, received-requests
  const [showRequestModal, setShowRequestModal] = useState(false);
  const [selectedPosition, setSelectedPosition] = useState(null);
  const [offeredAmount, setOfferedAmount] = useState("");

  const load = async () => {
    if (!user) {
      setLoading(false);
      return;
    }
    try {
      const [tradeRes, allRes, requestsRes] = await Promise.all([
        fetchTradePositions(),
        fetchPositions(),
        getTradeRequests(user._id),
      ]);
      setTradePositions(tradeRes.positions || []);
      setMyPositions((allRes.positions || []).filter((p) => p.userId?._id === user._id || p.userId === user._id));
      setTradeRequests(requestsRes.tradeRequests || []);
    } catch (err) {
      setError(err.message || "Failed to load positions");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    load();
  }, [user]);

  const handleListMine = async () => {
    if (!user) {
      alert("Please log in first.");
      return;
    }
    const owned = myPositions.find((p) => !p.isForTrade);
    if (!owned) {
      alert("You don't have any positions to list, or all are already listed.");
      return;
    }
    try {
      await listPositionForTrade(owned._id);
      await load();
      alert("Your position was listed for trade.");
    } catch (err) {
      alert(err.message || "Failed to list position");
    }
  };

  const handleRequestTrade = (position) => {
    setSelectedPosition(position);
    setOfferedAmount("");
    setShowRequestModal(true);
  };

  const handleSubmitTradeRequest = async () => {
    if (!user || !selectedPosition) return;

    try {
      await createTradeRequest({
        requesterId: user._id,
        targetPositionId: selectedPosition._id,
        offeredAmount: offeredAmount ? parseFloat(offeredAmount) : 0,
        notes: `Trade request for position #${selectedPosition.positionNumber}`,
      });
      await load();
      setShowRequestModal(false);
      setSelectedPosition(null);
      alert("Trade request sent successfully!");
    } catch (err) {
      alert(err.message || "Failed to create trade request");
    }
  };

  const handleAcceptRequest = async (requestId) => {
    if (!user) return;
    if (!window.confirm("Accept this trade request? Positions will be swapped.")) return;

    try {
      await acceptTradeRequest(requestId, user._id);
      await load();
      alert("Trade request accepted. Positions swapped!");
    } catch (err) {
      alert(err.message || "Failed to accept trade request");
    }
  };

  const handleRejectRequest = async (requestId) => {
    if (!user) return;
    if (!window.confirm("Reject this trade request?")) return;

    try {
      await rejectTradeRequest(requestId, user._id);
      await load();
      alert("Trade request rejected");
    } catch (err) {
      alert(err.message || "Failed to reject trade request");
    }
  };

  if (!user) {
    return (
      <div className="section">
        <p className="muted">Please log in to view positions.</p>
      </div>
    );
  }

  const sentRequests = tradeRequests.filter((r) => r.requesterId._id === user._id || r.requesterId === user._id);
  const receivedRequests = tradeRequests.filter(
    (r) => r.status === "pending" && (r.targetPositionId?.userId?._id === user._id || r.targetPositionId?.userId === user._id)
  );

  return (
    <div className="section">
      <div className="flex between" style={{ marginBottom: 16 }}>
        <div>
          <h1 style={{ margin: "8px 0" }}>Position Trading</h1>
          <p className="muted">Request position trades, manage your requests, and view received requests</p>
        </div>
        <button type="button" className="btn primary" onClick={handleListMine}>
          List my position
        </button>
      </div>

      <div style={{ display: "flex", gap: 8, marginBottom: 16, borderBottom: "1px solid #e5e7eb" }}>
        <button
          type="button"
          className="btn secondary"
          onClick={() => setActiveTab("marketplace")}
          style={{
            background: activeTab === "marketplace" ? "#6366f1" : "transparent",
            color: activeTab === "marketplace" ? "white" : "#374151",
            border: "none",
            borderRadius: "8px 8px 0 0",
          }}
        >
          Marketplace
        </button>
        <button
          type="button"
          className="btn secondary"
          onClick={() => setActiveTab("my-requests")}
          style={{
            background: activeTab === "my-requests" ? "#6366f1" : "transparent",
            color: activeTab === "my-requests" ? "white" : "#374151",
            border: "none",
            borderRadius: "8px 8px 0 0",
          }}
        >
          My Requests ({sentRequests.length})
        </button>
        <button
          type="button"
          className="btn secondary"
          onClick={() => setActiveTab("received-requests")}
          style={{
            background: activeTab === "received-requests" ? "#6366f1" : "transparent",
            color: activeTab === "received-requests" ? "white" : "#374151",
            border: "none",
            borderRadius: "8px 8px 0 0",
          }}
        >
          Received ({receivedRequests.length})
        </button>
      </div>

      {loading && <p className="muted">Loading...</p>}
      {error && <p className="muted" style={{ color: "#b91c1c" }}>{error}</p>}

      {activeTab === "marketplace" && (
        <div className="card">
          <h3 style={{ margin: "0 0 16px 0" }}>Available Positions for Trade</h3>
          {tradePositions.length === 0 ? (
            <p className="muted">No positions available for trade</p>
          ) : (
            <table className="table">
              <thead>
                <tr>
                  <th>Gam3ya</th>
                  <th>Holder</th>
                  <th>Position</th>
                  <th>Status</th>
                  <th></th>
                </tr>
              </thead>
              <tbody>
                {tradePositions.map((pos) => (
                  <tr key={pos._id}>
                    <td>{pos.gam3yaId?.name || "—"}</td>
                    <td>{pos.userId?.username || "—"}</td>
                    <td>#{pos.positionNumber}</td>
                    <td>
                      <span className="pill" style={{ background: "#eef2ff", color: "#312e81" }}>
                        Open
                      </span>
                    </td>
                    <td>
                      <button
                        className="btn primary"
                        type="button"
                        onClick={() => handleRequestTrade(pos)}
                        disabled={!pos.isForTrade}
                      >
                        Request Position Trade
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </div>
      )}

      {activeTab === "my-requests" && (
        <div className="card">
          <h3 style={{ margin: "0 0 16px 0" }}>My Trade Requests</h3>
          {sentRequests.length === 0 ? (
            <p className="muted">You haven't sent any trade requests</p>
          ) : (
            <table className="table">
              <thead>
                <tr>
                  <th>Gam3ya</th>
                  <th>Target Position</th>
                  <th>Offered Amount</th>
                  <th>Status</th>
                  <th>Date</th>
                </tr>
              </thead>
              <tbody>
                {sentRequests.map((req) => (
                  <tr key={req._id}>
                    <td>{req.gam3yaId?.name || "—"}</td>
                    <td>#{req.targetPositionId?.positionNumber || "—"}</td>
                    <td>{req.offeredAmount || 0} EGP</td>
                    <td>
                      <span
                        className="pill"
                        style={{
                          background:
                            req.status === "accepted"
                              ? "#d1fae5"
                              : req.status === "rejected"
                              ? "#fee2e2"
                              : "#fef3c7",
                          color:
                            req.status === "accepted"
                              ? "#065f46"
                              : req.status === "rejected"
                              ? "#991b1b"
                              : "#92400e",
                        }}
                      >
                        {req.status?.toUpperCase() || "PENDING"}
                      </span>
                    </td>
                    <td>{new Date(req.createdAt).toLocaleDateString()}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </div>
      )}

      {activeTab === "received-requests" && (
        <div className="card">
          <h3 style={{ margin: "0 0 16px 0" }}>Received Trade Requests</h3>
          {receivedRequests.length === 0 ? (
            <p className="muted">No pending trade requests</p>
          ) : (
            <table className="table">
              <thead>
                <tr>
                  <th>Requester</th>
                  <th>Gam3ya</th>
                  <th>Position</th>
                  <th>Offered Amount</th>
                  <th>Date</th>
                  <th>Actions</th>
                </tr>
              </thead>
              <tbody>
                {receivedRequests.map((req) => (
                  <tr key={req._id}>
                    <td>{req.requesterId?.username || "—"}</td>
                    <td>{req.gam3yaId?.name || "—"}</td>
                    <td>#{req.targetPositionId?.positionNumber || "—"}</td>
                    <td>{req.offeredAmount || 0} EGP</td>
                    <td>{new Date(req.createdAt).toLocaleDateString()}</td>
                    <td>
                      <div className="flex" style={{ gap: 8 }}>
                        <button
                          className="btn primary"
                          type="button"
                          onClick={() => handleAcceptRequest(req._id)}
                        >
                          Accept
                        </button>
                        <button
                          className="btn secondary"
                          type="button"
                          onClick={() => handleRejectRequest(req._id)}
                        >
                          Reject
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </div>
      )}

      {showRequestModal && selectedPosition && (
        <div
          style={{
            position: "fixed",
            top: 0,
            left: 0,
            right: 0,
            bottom: 0,
            background: "rgba(0,0,0,0.5)",
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            zIndex: 1000,
          }}
          onClick={() => setShowRequestModal(false)}
        >
          <div
            className="card"
            style={{ maxWidth: 500, width: "90%", zIndex: 1001 }}
            onClick={(e) => e.stopPropagation()}
          >
            <h3 style={{ margin: "0 0 16px 0" }}>Request Position Trade</h3>
            <p><strong>Gam3ya:</strong> {selectedPosition.gam3yaId?.name}</p>
            <p><strong>Position:</strong> #{selectedPosition.positionNumber}</p>
            <p><strong>Current Holder:</strong> {selectedPosition.userId?.username}</p>
            <div style={{ marginTop: 16 }}>
              <label>
                Offered Amount (EGP) <span className="muted">(optional)</span>
              </label>
              <input
                type="number"
                value={offeredAmount}
                onChange={(e) => setOfferedAmount(e.target.value)}
                placeholder="0"
                style={{ width: "100%", padding: 8, marginTop: 4, borderRadius: 4, border: "1px solid #d1d5db" }}
              />
            </div>
            <div style={{ display: "flex", gap: 8, marginTop: 16 }}>
              <button className="btn primary" type="button" onClick={handleSubmitTradeRequest}>
                Send Request
              </button>
              <button className="btn secondary" type="button" onClick={() => setShowRequestModal(false)}>
                Cancel
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

export default PositionsPage;
