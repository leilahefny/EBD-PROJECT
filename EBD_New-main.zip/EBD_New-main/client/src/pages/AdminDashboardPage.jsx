import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { useAuth } from "../context/AuthContext.jsx";
import { fetchAllUsers, fetchGam3yas, fetchPositions, updateUserAdmin } from "../services/api.js";

function AdminDashboardPage() {
  const { user } = useAuth();
  const navigate = useNavigate();
  const [users, setUsers] = useState([]);
  const [gam3yas, setGam3yas] = useState([]);
  const [positions, setPositions] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  useEffect(() => {
    if (!user) return;
    if (user.role !== "admin") {
      navigate("/dashboard");
      return;
    }
    const load = async () => {
      try {
        const [usersRes, gam3yaRes, posRes] = await Promise.all([
          fetchAllUsers(user._id),
          fetchGam3yas(),
          fetchPositions(),
        ]);
        setUsers(usersRes.users || []);
        setGam3yas(gam3yaRes.gam3yas || []);
        setPositions(posRes.positions || []);
      } catch (err) {
        setError(err.message || "Failed to load admin data");
      } finally {
        setLoading(false);
      }
    };
    load();
  }, [user, navigate]);

  const handleUserUpdate = async (id, partial) => {
    if (!user) return;
    try {
      const res = await updateUserAdmin(id, user._id, partial);
      setUsers((prev) => prev.map((u) => (u._id === id ? res.user : u)));
    } catch (err) {
      alert(err.message || "Failed to update user");
    }
  };

  if (!user) {
    return (
      <div className="section">
        <p className="muted">Please log in as an admin to view this page.</p>
      </div>
    );
  }

  if (user.role !== "admin") {
    return (
      <div className="section">
        <p className="muted">You do not have permission to view the admin dashboard.</p>
      </div>
    );
  }

  return (
    <div className="section">
      <div className="flex between" style={{ marginBottom: 20 }}>
        <div>
          <div className="badge">Admin dashboard</div>
          <h1 style={{ margin: "8px 0 0" }}>Platform oversight</h1>
          <p className="muted">
            View Gam3yas, users, and positions to enforce Gam3ya rules and credit scores.
          </p>
        </div>
      </div>

      {loading && <p className="muted">Loading admin data…</p>}
      {error && (
        <p className="muted" style={{ color: "#b91c1c" }}>
          {error}
        </p>
      )}

      <div className="grid cols-3">
        <div className="card">
          <p className="muted">Total users</p>
          <h2 style={{ margin: "6px 0" }}>{users.length}</h2>
        </div>
        <div className="card">
          <p className="muted">Total Gam3yas</p>
          <h2 style={{ margin: "6px 0" }}>{gam3yas.length}</h2>
        </div>
        <div className="card">
          <p className="muted">Total positions</p>
          <h2 style={{ margin: "6px 0" }}>{positions.length}</h2>
        </div>
      </div>

      <div className="card" style={{ marginTop: 20 }}>
        <div className="flex between" style={{ marginBottom: 8 }}>
          <h3 style={{ margin: 0 }}>Users & credit scores</h3>
          <div className="pill">Suspend or warn if needed</div>
        </div>
        <table className="table">
          <thead>
            <tr>
              <th>Name</th>
              <th>Email</th>
              <th>Role</th>
              <th>Credit score</th>
              <th>Status</th>
              <th>Warnings</th>
            </tr>
          </thead>
          <tbody>
            {users.map((u) => (
              <tr key={u._id}>
                <td>{u.username}</td>
                <td>{u.email}</td>
                <td>{u.role}</td>
                <td>
                  <input
                    type="number"
                    defaultValue={u.creditScore}
                    min={0}
                    max={200}
                    style={{ width: 70, padding: 4, borderRadius: 6, border: "1px solid #e2e8f0" }}
                    onBlur={(e) =>
                      handleUserUpdate(u._id, { creditScore: Number(e.target.value) })
                    }
                  />
                </td>
                <td>
                  <select
                    defaultValue={u.status}
                    onChange={(e) => handleUserUpdate(u._id, { status: e.target.value })}
                    style={{ padding: 4, borderRadius: 6, border: "1px solid #e2e8f0" }}
                  >
                    <option value="active">active</option>
                    <option value="suspended">suspended</option>
                  </select>
                </td>
                <td>
                  <textarea
                    defaultValue={u.warningNotes}
                    rows={1}
                    style={{
                      width: "100%",
                      padding: 4,
                      borderRadius: 6,
                      border: "1px solid #e2e8f0",
                      resize: "vertical",
                    }}
                    onBlur={(e) => handleUserUpdate(u._id, { warningNotes: e.target.value })}
                  />
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      <div className="card" style={{ marginTop: 20 }}>
        <div className="flex between" style={{ marginBottom: 8 }}>
          <h3 style={{ margin: 0 }}>Gam3ya overview</h3>
          <div className="pill">Members, amounts, and schedule</div>
        </div>
        <table className="table">
          <thead>
            <tr>
              <th>Name</th>
              <th>Monthly amount</th>
              <th>Members</th>
              <th>Max members</th>
            </tr>
          </thead>
          <tbody>
            {gam3yas.map((g) => (
              <tr key={g._id}>
                <td>{g.name}</td>
                <td>{g.monthlyAmount} EGP</td>
                <td>{g.members?.length || 0}</td>
                <td>{g.maxMembers}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}

export default AdminDashboardPage;


