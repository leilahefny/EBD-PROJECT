import { useEffect, useState } from "react";
import { useParams, useNavigate } from "react-router-dom";
import { useAuth } from "../context/AuthContext.jsx";
import { getGam3yaById, updateGam3ya, deleteGam3ya } from "../services/api.js";

function Gam3yaDetailsPage() {
  const { id } = useParams();
  const navigate = useNavigate();
  const { user } = useAuth();
  const [gam3ya, setGam3ya] = useState(null);
  const [positions, setPositions] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  const load = async () => {
    try {
      const data = await getGam3yaById(id);
      setGam3ya(data.gam3ya);
      setPositions(data.positions || []);
    } catch (err) {
      setError(err.message || "Failed to load Gam3ya details");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    load();
  }, [id]);

  const isMember = user && gam3ya?.members?.some((m) => m._id === user._id || m === user._id);
  const isAdmin = user?.role === "admin";
  const canEdit = isAdmin;

  const handleDelete = async () => {
    if (!window.confirm("Are you sure you want to delete this Gam3ya? This action cannot be undone.")) {
      return;
    }
    try {
      await deleteGam3ya(id);
      alert("Gam3ya deleted successfully");
      navigate("/gam3yas");
    } catch (err) {
      alert(err.message || "Failed to delete Gam3ya");
    }
  };

  if (loading) {
    return (
      <div className="section">
        <p className="muted">Loading Gam3ya details...</p>
      </div>
    );
  }

  if (error || !gam3ya) {
    return (
      <div className="section">
        <p className="muted" style={{ color: "#b91c1c" }}>
          {error || "Gam3ya not found"}
        </p>
      </div>
    );
  }

  const statusColors = {
    open: { bg: "#eef2ff", color: "#312e81" },
    ongoing: { bg: "#fef3c7", color: "#92400e" },
    completed: { bg: "#d1fae5", color: "#065f46" },
  };

  return (
    <div className="section">
      <div className="flex between" style={{ marginBottom: 24 }}>
        <div>
          <button
            type="button"
            className="btn secondary"
            onClick={() => navigate("/gam3yas")}
            style={{ marginBottom: 16 }}
          >
            ← Back to Gam3yas
          </button>
          <h1 style={{ margin: "8px 0" }}>{gam3ya.name}</h1>
          <p className="muted">View full Gam3ya details, members, positions, and schedule</p>
        </div>
        {canEdit && (
          <div className="flex" style={{ gap: 8 }}>
            <button
              type="button"
              className="btn secondary"
              onClick={() => navigate(`/gam3yas/${id}/edit`)}
            >
              Edit
            </button>
            <button type="button" className="btn" style={{ background: "#b91c1c", color: "white" }} onClick={handleDelete}>
              Delete
            </button>
          </div>
        )}
      </div>

      <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(300px, 1fr))", gap: 16, marginBottom: 24 }}>
        <div className="card">
          <h3 style={{ margin: "0 0 8px 0" }}>Basic Info</h3>
          <p><strong>Monthly Amount:</strong> {gam3ya.monthlyAmount} EGP</p>
          <p><strong>Members:</strong> {gam3ya.members?.length || 0} / {gam3ya.maxMembers}</p>
          <p>
            <strong>Status:</strong>{" "}
            <span
              className="pill"
              style={{
                background: statusColors[gam3ya.status]?.bg || "#e5e7eb",
                color: statusColors[gam3ya.status]?.color || "#374151",
              }}
            >
              {gam3ya.status?.toUpperCase() || "UNKNOWN"}
            </span>
          </p>
        </div>

        <div className="card">
          <h3 style={{ margin: "0 0 8px 0" }}>Schedule</h3>
          {gam3ya.startDate ? (
            <>
              <p><strong>Start Date:</strong> {new Date(gam3ya.startDate).toLocaleDateString()}</p>
              {gam3ya.endDate && (
                <p><strong>End Date:</strong> {new Date(gam3ya.endDate).toLocaleDateString()}</p>
              )}
            </>
          ) : (
            <p className="muted">Not started yet</p>
          )}
        </div>
      </div>

      {gam3ya.paymentSchedule && gam3ya.paymentSchedule.length > 0 && (
        <div className="card" style={{ marginBottom: 24 }}>
          <h3 style={{ margin: "0 0 16px 0" }}>Payment Schedule</h3>
          <table className="table">
            <thead>
              <tr>
                <th>Round</th>
                <th>Position</th>
                <th>Payment Date</th>
                <th>Deadline</th>
                <th>Status</th>
              </tr>
            </thead>
            <tbody>
              {gam3ya.paymentSchedule.map((schedule, idx) => (
                <tr key={idx}>
                  <td>{schedule.round}</td>
                  <td>#{schedule.positionNumber}</td>
                  <td>{new Date(schedule.paymentDate).toLocaleDateString()}</td>
                  <td>{new Date(schedule.deadline).toLocaleDateString()}</td>
                  <td>
                    <span
                      className="pill"
                      style={{
                        background:
                          schedule.status === "paid"
                            ? "#d1fae5"
                            : schedule.status === "missed"
                            ? "#fee2e2"
                            : "#e5e7eb",
                        color:
                          schedule.status === "paid"
                            ? "#065f46"
                            : schedule.status === "missed"
                            ? "#991b1b"
                            : "#374151",
                      }}
                    >
                      {schedule.status?.toUpperCase() || "PENDING"}
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      <div className="card" style={{ marginBottom: 24 }}>
        <h3 style={{ margin: "0 0 16px 0" }}>Members ({gam3ya.members?.length || 0})</h3>
        {gam3ya.members && gam3ya.members.length > 0 ? (
          <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(200px, 1fr))", gap: 12 }}>
            {gam3ya.members.map((member) => (
              <div key={member._id || member} style={{ padding: 12, background: "#f9fafb", borderRadius: 8 }}>
                <p style={{ margin: 0, fontWeight: 500 }}>{member.username || "Unknown"}</p>
                <p className="muted" style={{ margin: "4px 0 0 0", fontSize: "0.875rem" }}>
                  {member.email || ""}
                </p>
                {member.creditScore !== undefined && (
                  <p className="muted" style={{ margin: "4px 0 0 0", fontSize: "0.875rem" }}>
                    Credit: {member.creditScore}
                  </p>
                )}
              </div>
            ))}
          </div>
        ) : (
          <p className="muted">No members yet</p>
        )}
      </div>

      {positions.length > 0 && (
        <div className="card">
          <h3 style={{ margin: "0 0 16px 0" }}>Position Order</h3>
          <table className="table">
            <thead>
              <tr>
                <th>Position #</th>
                <th>Holder</th>
                <th>Status</th>
              </tr>
            </thead>
            <tbody>
              {positions
                .sort((a, b) => a.positionNumber - b.positionNumber)
                .map((pos) => (
                  <tr key={pos._id}>
                    <td>#{pos.positionNumber}</td>
                    <td>{pos.userId?.username || "Unknown"}</td>
                    <td>
                      {pos.isForTrade ? (
                        <span className="pill" style={{ background: "#fef3c7", color: "#92400e" }}>
                          FOR TRADE
                        </span>
                      ) : (
                        <span className="pill" style={{ background: "#e5e7eb", color: "#374151" }}>
                          ACTIVE
                        </span>
                      )}
                    </td>
                  </tr>
                ))}
            </tbody>
          </table>
        </div>
      )}

      {!isMember && !isAdmin && (
        <div className="card" style={{ background: "#fef3c7", border: "1px solid #fbbf24" }}>
          <p style={{ margin: 0, color: "#92400e" }}>
            <strong>Note:</strong> You are not a member of this Gam3ya. Some features may be limited.
          </p>
        </div>
      )}
    </div>
  );
}

export default Gam3yaDetailsPage;

