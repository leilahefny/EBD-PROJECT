import { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { useAuth } from "../context/AuthContext.jsx";

function LoginPage() {
  const { login } = useAuth();
  const navigate = useNavigate();
  const [form, setForm] = useState({ email: "", password: "" });
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  const handleChange = (e) => {
    setForm((prev) => ({ ...prev, [e.target.name]: e.target.value }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError("");
    setLoading(true);
    try {
      await login(form.email, form.password);
      navigate("/dashboard");
    } catch (err) {
      setError(err.message || "Login failed");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="section" style={{ maxWidth: 520, margin: '0 auto' }}>
      <div className="card">
        <div className="badge">Authentication</div>
        <h1 style={{ marginBottom: 6 }}>Log in</h1>
        <p className="muted" style={{ marginTop: 0 }}>
          Connects to the Express API and verifies hashed passwords.
        </p>

        {error && (
          <div className="pill" style={{ background: "#fee2e2", color: "#b91c1c", marginBottom: 10 }}>
            {error}
          </div>
        )}

        <form className="grid" style={{ gap: 14, marginTop: 16 }} onSubmit={handleSubmit}>
          <label className="grid" style={{ gap: 6 }}>
            Email
            <input
              name="email"
              type="email"
              placeholder="you@example.com"
              value={form.email}
              onChange={handleChange}
              style={{
                padding: 12,
                borderRadius: 10,
                border: '1px solid #e2e8f0',
                fontSize: 15,
              }}
            />
          </label>

          <label className="grid" style={{ gap: 6 }}>
            Password
            <input
              name="password"
              type="password"
              placeholder="••••••••"
              value={form.password}
              onChange={handleChange}
              style={{
                padding: 12,
                borderRadius: 10,
                border: '1px solid #e2e8f0',
                fontSize: 15,
              }}
            />
          </label>

          <button type="submit" className="btn primary" disabled={loading}>
            {loading ? "Signing in..." : "Sign in"}
          </button>
        </form>

        <p className="muted" style={{ marginTop: 12 }}>
          New here? <Link to="/register">Create an account</Link>
        </p>
      </div>
    </div>
  )
}

export default LoginPage

