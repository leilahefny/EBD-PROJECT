import { createBrowserRouter } from "react-router-dom";
import AppLayout from "./components/AppLayout";
import DashboardPage from "./pages/DashboardPage";
import Gam3yaListPage from "./pages/Gam3yaListPage";
import Gam3yaDetailsPage from "./pages/Gam3yaDetailsPage";
import HomePage from "./pages/HomePage";
import LoginPage from "./pages/LoginPage";
import NotFoundPage from "./pages/NotFoundPage";
import PositionsPage from "./pages/PositionsPage";
import RegisterPage from "./pages/RegisterPage.jsx";
import AdminDashboardPage from "./pages/AdminDashboardPage.jsx";

const router = createBrowserRouter([
  {
    path: '/',
    element: <AppLayout />,
    children: [
      { index: true, element: <HomePage /> },
      { path: "dashboard", element: <DashboardPage /> },
      { path: "login", element: <LoginPage /> },
      { path: "register", element: <RegisterPage /> },
      { path: "gam3yas", element: <Gam3yaListPage /> },
      { path: "gam3yas/:id", element: <Gam3yaDetailsPage /> },
      { path: "positions", element: <PositionsPage /> },
      { path: "admin", element: <AdminDashboardPage /> },
      { path: "*", element: <NotFoundPage /> },
    ],
  },
])

export default router

