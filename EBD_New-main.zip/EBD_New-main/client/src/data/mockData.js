export const heroHighlights = [
  'Create or join trusted Gam3ya groups',
  'Trade payout positions when plans change',
  'Track monthly payments with transparency',
]

export const featuredGam3yas = [
  {
    id: 'g1',
    name: 'Sprint Savers',
    monthlyAmount: 1500,
    maxMembers: 8,
    filled: 6,
    nextPayout: 'Feb 10',
  },
  {
    id: 'g2',
    name: 'Early Bird Boost',
    monthlyAmount: 2000,
    maxMembers: 10,
    filled: 10,
    nextPayout: 'Jan 28',
  },
  {
    id: 'g3',
    name: 'Family Circle',
    monthlyAmount: 750,
    maxMembers: 6,
    filled: 4,
    nextPayout: 'Feb 15',
  },
]

export const positionsForTrade = [
  {
    id: 'p1',
    gam3ya: 'Sprint Savers',
    currentHolder: 'Noura',
    positionNumber: 2,
    asking: 'Swap for 5 or later',
    status: 'Open',
  },
  {
    id: 'p2',
    gam3ya: 'Early Bird Boost',
    currentHolder: 'Karim',
    positionNumber: 1,
    asking: '3,000 EGP',
    status: 'Negotiable',
  },
  {
    id: 'p3',
    gam3ya: 'Family Circle',
    currentHolder: 'Mina',
    positionNumber: 5,
    asking: 'Swap for 3',
    status: 'Open',
  },
]

export const dashboardStats = {
  contribution: '1,500 EGP',
  nextPayout: 'Feb 10, 2025',
  position: '#3 in Sprint Savers',
  trustScore: '92 / 100',
}

export const activityFeed = [
  { id: 'a1', text: 'You joined Sprint Savers Gam3ya.', time: '2h ago' },
  { id: 'a2', text: 'Monthly payment marked as paid for January.', time: '1d ago' },
  { id: 'a3', text: 'Leila listed Position #2 for trade.', time: '2d ago' },
]

export const featureGrid = [
  {
    title: 'Create or Join Gam3ya',
    detail: 'Spin up a group in seconds or join an existing circle with clear terms.',
  },
  {
    title: 'Auto Payout Order',
    detail: 'Let the platform generate the payout sequence transparently.',
  },
  {
    title: 'Payment Tracking',
    detail: 'See who paid this month and who still needs a reminder.',
  },
  {
    title: 'Position Marketplace',
    detail: 'List, buy, or swap payout positions when plans change.',
  },
  {
    title: 'Trust & History',
    detail: 'Build credibility through consistent payments and trading history.',
  },
  {
    title: 'Mobile-Friendly',
    detail: 'Clean, responsive UI tailored for quick actions on the go.',
  },
]

