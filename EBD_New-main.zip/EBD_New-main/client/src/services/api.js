const API_URL = import.meta.env.VITE_API_URL || "http://localhost:5000";

async function handleResponse(res) {
  if (!res.ok) {
    const errorBody = await res.json().catch(() => ({}));
    const message = errorBody.message || `Request failed with status ${res.status}`;
    throw new Error(message);
  }
  return res.json();
}

// ---------- Auth ----------
export async function registerUser(payload) {
  const res = await fetch(`${API_URL}/api/users/register`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(payload),
  });
  return handleResponse(res);
}

export async function loginUser(payload) {
  const res = await fetch(`${API_URL}/api/users/login`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(payload),
  });
  return handleResponse(res);
}

// ---------- Admin / Users ----------
export async function fetchAllUsers(adminUserId) {
  const res = await fetch(`${API_URL}/api/users`, {
    headers: {
      "X-Admin-User-Id": adminUserId,
    },
  });
  return handleResponse(res);
}

export async function updateUserAdmin(id, adminUserId, updates) {
  const res = await fetch(`${API_URL}/api/users/${id}/admin`, {
    method: "PATCH",
    headers: {
      "Content-Type": "application/json",
      "X-Admin-User-Id": adminUserId,
    },
    body: JSON.stringify(updates),
  });
  return handleResponse(res);
}

// ---------- Gam3ya ----------
export async function fetchGam3yas() {
  const res = await fetch(`${API_URL}/api/gam3ya`);
  return handleResponse(res);
}

export async function createGam3ya(payload) {
  const res = await fetch(`${API_URL}/api/gam3ya`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(payload),
  });
  return handleResponse(res);
}

export async function joinGam3ya(gam3yaId, userId) {
  const res = await fetch(`${API_URL}/api/gam3ya/${gam3yaId}/join`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ userId }),
  });
  return handleResponse(res);
}

export async function getGam3yaById(gam3yaId) {
  const res = await fetch(`${API_URL}/api/gam3ya/${gam3yaId}`);
  return handleResponse(res);
}

export async function generatePayoutOrder(gam3yaId) {
  const res = await fetch(`${API_URL}/api/gam3ya/${gam3yaId}/generate-positions`, {
    method: "POST",
  });
  return handleResponse(res);
}

export async function updateGam3ya(gam3yaId, updates) {
  const res = await fetch(`${API_URL}/api/gam3ya/${gam3yaId}`, {
    method: "PUT",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(updates),
  });
  return handleResponse(res);
}

export async function deleteGam3ya(gam3yaId) {
  const res = await fetch(`${API_URL}/api/gam3ya/${gam3yaId}`, {
    method: "DELETE",
  });
  return handleResponse(res);
}

// ---------- Positions ----------
export async function fetchPositions() {
  const res = await fetch(`${API_URL}/api/positions`);
  return handleResponse(res);
}

export async function fetchTradePositions() {
  const res = await fetch(`${API_URL}/api/positions/trade`);
  return handleResponse(res);
}

export async function listPositionForTrade(positionId) {
  const res = await fetch(`${API_URL}/api/positions/${positionId}/list`, {
    method: "POST",
  });
  return handleResponse(res);
}

export async function buyPosition(positionId, newUserId) {
  const res = await fetch(`${API_URL}/api/positions/${positionId}/buy`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ newUserId }),
  });
  return handleResponse(res);
}

export async function swapPositions(position1Id, position2Id) {
  const res = await fetch(`${API_URL}/api/positions/swap`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ position1Id, position2Id }),
  });
  return handleResponse(res);
}

export async function markPositionPaid(positionId) {
  const res = await fetch(`${API_URL}/api/positions/${positionId}/pay`, {
    method: "POST",
  });
  return handleResponse(res);
}

// ---------- Trade Requests ----------
export async function createTradeRequest(payload) {
  const res = await fetch(`${API_URL}/api/trade-requests`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(payload),
  });
  return handleResponse(res);
}

export async function getTradeRequests(userId, type) {
  const params = new URLSearchParams({ userId });
  if (type) params.append("type", type);
  const res = await fetch(`${API_URL}/api/trade-requests?${params}`);
  return handleResponse(res);
}

export async function acceptTradeRequest(requestId, userId) {
  const res = await fetch(`${API_URL}/api/trade-requests/${requestId}/accept`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ userId }),
  });
  return handleResponse(res);
}

export async function rejectTradeRequest(requestId, userId) {
  const res = await fetch(`${API_URL}/api/trade-requests/${requestId}/reject`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ userId }),
  });
  return handleResponse(res);
}

// ---------- Notifications ----------
export async function fetchNotifications(userId) {
  const res = await fetch(`${API_URL}/api/notifications?userId=${userId}`);
  return handleResponse(res);
}

export async function markNotificationRead(notificationId, userId) {
  const res = await fetch(`${API_URL}/api/notifications/${notificationId}/read`, {
    method: "PATCH",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ userId }),
  });
  return handleResponse(res);
}

export async function markAllNotificationsRead(userId) {
  const res = await fetch(`${API_URL}/api/notifications/read-all`, {
    method: "PATCH",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ userId }),
  });
  return handleResponse(res);
}

export async function deleteNotification(notificationId, userId) {
  const res = await fetch(`${API_URL}/api/notifications/${notificationId}`, {
    method: "DELETE",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ userId }),
  });
  return handleResponse(res);
}


