# Gama3li Shokran – Frontend (Milestone 2)

Static React UI built with Vite to satisfy Milestone 2 requirements.

## Available pages
- `/` – Home/marketing overview
- `/dashboard` – Member dashboard snapshot
- `/gam3yas` – Static list of available groups
- `/positions` – Static payout position marketplace
- `/login` – Static authentication form

Routing is handled client-side with React Router; all data is hardcoded inside `src/data/mockData.js`.

## Run locally
```bash
cd client
npm install
npm run dev
```

Vite will serve the SPA at the default `http://localhost:5173`.

