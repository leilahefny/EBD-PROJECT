import Gam3ya from "../models/Gam3ya.js";

/**
 * Middleware to check if user is a member of a Gam3ya
 * Expects gam3yaId in req.params.id or req.body.gam3yaId
 * Expects userId in req.body.userId or req.headers['x-user-id']
 */
export const requireMembership = async (req, res, next) => {
  try {
    const gam3yaId = req.params.id || req.params.gam3yaId || req.body.gam3yaId;
    const userId = req.body.userId || req.headers["x-user-id"];

    if (!gam3yaId) {
      return res.status(400).json({ message: "Gam3ya ID is required" });
    }

    if (!userId) {
      return res.status(400).json({ message: "User ID is required" });
    }

    const gam3ya = await Gam3ya.findById(gam3yaId);
    if (!gam3ya) {
      return res.status(404).json({ message: "Gam3ya not found" });
    }

    const isMember = gam3ya.members.some((m) => m.toString() === userId.toString());
    if (!isMember) {
      return res.status(403).json({
        message: "You are not a member of this Gam3ya. Please join it first.",
      });
    }

    req.gam3ya = gam3ya;
    next();
  } catch (error) {
    res.status(500).json({ message: "Membership validation failed", error: error.message });
  }
};

