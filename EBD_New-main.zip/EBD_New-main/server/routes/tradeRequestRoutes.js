import express from "express";
import {
  acceptTradeRequest,
  createTradeRequest,
  getTradeRequests,
  rejectTradeRequest,
} from "../controllers/tradeRequestController.js";

const router = express.Router();

router.post("/", createTradeRequest);
router.get("/", getTradeRequests);
router.post("/:requestId/accept", acceptTradeRequest);
router.post("/:requestId/reject", rejectTradeRequest);

export default router;

