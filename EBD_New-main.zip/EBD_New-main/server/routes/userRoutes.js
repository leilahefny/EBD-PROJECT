import express from "express";
import {
  getAllUsers,
  loginUser,
  registerUser,
  updateUserAdminFields,
} from "../controllers/userController.js";

const router = express.Router();

router.post("/register", registerUser);
router.post("/login", loginUser);
router.get("/", getAllUsers);
router.patch("/:id/admin", updateUserAdminFields);

export default router;

