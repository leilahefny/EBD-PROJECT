import mongoose from "mongoose";

const userSchema = new mongoose.Schema(
  {
    username: {
      type: String,
      required: true,
      trim: true,
      unique: true,
    },
    email: {
      type: String,
      required: true,
      trim: true,
      lowercase: true,
      unique: true,
    },
    password: {
      type: String,
      required: true,
      minlength: 6,
    },
    // Simple role-based access: "user" or "admin"
    role: {
      type: String,
      enum: ["user", "admin"],
      default: "user",
    },
    // Admin can adjust this to reflect reliability in Gam3ya participation
    creditScore: {
      type: Number,
      default: 100,
      min: 0,
      max: 200,
    },
    // Admin moderation state
    status: {
      type: String,
      enum: ["active", "suspended"],
      default: "active",
    },
    warningNotes: {
      type: String,
      default: "",
      trim: true,
    },
  },
  { timestamps: true }
);

const User = mongoose.model("User", userSchema);

export default User;

