import mongoose from "mongoose";

const tradeRequestSchema = new mongoose.Schema(
  {
    requesterId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "User",
      required: true,
    },
    targetPositionId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "Position",
      required: true,
    },
    requesterPositionId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "Position",
    },
    offeredAmount: {
      type: Number,
      min: 0,
    },
    status: {
      type: String,
      enum: ["pending", "accepted", "rejected", "cancelled"],
      default: "pending",
    },
    gam3yaId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "Gam3ya",
      required: true,
    },
    notes: {
      type: String,
    },
  },
  { timestamps: true }
);

const TradeRequest = mongoose.model("TradeRequest", tradeRequestSchema);

export default TradeRequest;

