import mongoose from "mongoose";

const notificationSchema = new mongoose.Schema(
  {
    userId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "User",
      required: true,
    },
    type: {
      type: String,
      enum: [
        "trade_request_received",
        "trade_request_accepted",
        "trade_request_rejected",
        "payment_deadline_upcoming",
        "payment_missed",
        "admin_warning",
        "admin_action",
        "trade_activity",
      ],
      required: true,
    },
    title: {
      type: String,
      required: true,
    },
    message: {
      type: String,
      required: true,
    },
    relatedGam3yaId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "Gam3ya",
    },
    relatedPositionId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "Position",
    },
    relatedTradeRequestId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "TradeRequest",
    },
    isRead: {
      type: Boolean,
      default: false,
    },
    metadata: {
      type: mongoose.Schema.Types.Mixed,
    },
  },
  { timestamps: true }
);

const Notification = mongoose.model("Notification", notificationSchema);

export default Notification;

