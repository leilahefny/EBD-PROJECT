import mongoose from "mongoose";

const positionSchema = new mongoose.Schema(
  {
    gam3yaId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "Gam3ya",
      required: true,
    },
    userId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "User",
      required: true,
    },
    positionNumber: {
      type: Number,
      required: true,
      min: 1,
    },
    isForTrade: {
      type: Boolean,
      default: false,
    },
    // Simple monthly payment tracking flag for current cycle
    paidThisMonth: {
      type: Boolean,
      default: false,
    },
    // Simple history: who bought/swapped this position and when
    tradeHistory: [
      {
        type: {
          type: String,
          enum: ["listed", "bought", "swapped"],
        },
        fromUser: { type: mongoose.Schema.Types.ObjectId, ref: "User" },
        toUser: { type: mongoose.Schema.Types.ObjectId, ref: "User" },
        at: { type: Date, default: Date.now },
        note: { type: String, trim: true },
      },
    ],
  },
  { timestamps: true }
);

const Position = mongoose.model("Position", positionSchema);

export default Position;

