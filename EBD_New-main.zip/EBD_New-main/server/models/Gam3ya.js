import mongoose from "mongoose";

const paymentScheduleSchema = new mongoose.Schema({
  round: { type: Number, required: true },
  positionNumber: { type: Number, required: true },
  paymentDate: { type: Date, required: true },
  deadline: { type: Date, required: true },
  status: { type: String, enum: ["pending", "paid", "missed"], default: "pending" },
}, { _id: false });

const gam3yaSchema = new mongoose.Schema(
  {
    name: {
      type: String,
      required: true,
      trim: true,
    },
    monthlyAmount: {
      type: Number,
      required: true,
      min: 0,
    },
    maxMembers: {
      type: Number,
      required: true,
      min: 1,
    },
    members: [
      {
        type: mongoose.Schema.Types.ObjectId,
        ref: "User",
      },
    ],
    startDate: {
      type: Date,
      required: true,
    },
    endDate: {
      type: Date,
    },
    status: {
      type: String,
      enum: ["open", "ongoing", "completed"],
      default: "open",
    },
    paymentSchedule: [paymentScheduleSchema],
  },
  { timestamps: true }
);

// Calculate end date based on maxMembers (each member gets one month)
gam3yaSchema.pre("save", function(next) {
  if (this.startDate && this.maxMembers && !this.endDate) {
    const endDate = new Date(this.startDate);
    endDate.setMonth(endDate.getMonth() + this.maxMembers);
    this.endDate = endDate;
  }
  next();
});

const Gam3ya = mongoose.model("Gam3ya", gam3yaSchema);

export default Gam3ya;

