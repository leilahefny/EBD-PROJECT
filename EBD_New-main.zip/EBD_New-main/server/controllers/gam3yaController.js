import Gam3ya from "../models/Gam3ya.js";
import Position from "../models/Position.js";

export const createGam3ya = async (req, res) => {
  try {
    const gam3ya = await Gam3ya.create(req.body);
    res.status(201).json({ message: "Gam3ya created", gam3ya });
  } catch (error) {
    res.status(500).json({ message: "Failed to create gam3ya", error: error.message });
  }
};

export const getGam3yas = async (_req, res) => {
  try {
    const gam3yas = await Gam3ya.find().populate("members", "username email");
    res.status(200).json({ gam3yas });
  } catch (error) {
    res.status(500).json({ message: "Failed to fetch gam3yas", error: error.message });
  }
};

export const getGam3yaById = async (req, res) => {
  try {
    const gam3ya = await Gam3ya.findById(req.params.id)
      .populate("members", "username email creditScore status")
      .populate("paymentSchedule");
    
    if (!gam3ya) {
      return res.status(404).json({ message: "Gam3ya not found" });
    }

    // Get positions with trade history
    const positions = await Position.find({ gam3yaId: gam3ya._id })
      .populate("userId", "username email")
      .sort({ positionNumber: 1 });

    res.status(200).json({
      gam3ya,
      positions,
    });
  } catch (error) {
    res.status(500).json({ message: "Failed to fetch gam3ya", error: error.message });
  }
};

export const updateGam3ya = async (req, res) => {
  try {
    const gam3ya = await Gam3ya.findByIdAndUpdate(req.params.id, req.body, {
      new: true,
      runValidators: true,
    });
    if (!gam3ya) {
      return res.status(404).json({ message: "Gam3ya not found" });
    }
    res.status(200).json({ message: "Gam3ya updated", gam3ya });
  } catch (error) {
    res.status(500).json({ message: "Failed to update gam3ya", error: error.message });
  }
};

export const deleteGam3ya = async (req, res) => {
  try {
    const gam3ya = await Gam3ya.findByIdAndDelete(req.params.id);
    if (!gam3ya) {
      return res.status(404).json({ message: "Gam3ya not found" });
    }
    res.status(200).json({ message: "Gam3ya deleted" });
  } catch (error) {
    res.status(500).json({ message: "Failed to delete gam3ya", error: error.message });
  }
};

export const joinGam3ya = async (req, res) => {
  try {
    const { userId } = req.body;
    const gam3ya = await Gam3ya.findById(req.params.id);

    if (!gam3ya) {
      return res.status(404).json({ message: "Gam3ya not found" });
    }

    // Check if full
    if (gam3ya.members.length >= gam3ya.maxMembers) {
      return res.status(400).json({ message: "Gam3ya is full" });
    }

    // Check if already member
    if (gam3ya.members.some((m) => m.toString() === userId.toString())) {
      return res.status(400).json({ message: "User already in gam3ya" });
    }

    // Check if already started (has positions or status is ongoing/completed)
    if (gam3ya.status === "ongoing" || gam3ya.status === "completed") {
      return res.status(400).json({ message: "Gam3ya has already started. Cannot join." });
    }

    // Check if positions exist (means it started)
    const existingPositions = await Position.countDocuments({ gam3yaId: gam3ya._id });
    if (existingPositions > 0) {
      return res.status(400).json({ message: "Gam3ya has already started. Cannot join." });
    }

    gam3ya.members.push(userId);
    await gam3ya.save();

    const populated = await Gam3ya.findById(gam3ya._id).populate("members", "username email");

    res.status(200).json({ message: "Joined gam3ya", gam3ya: populated });
  } catch (error) {
    res.status(500).json({ message: "Failed to join gam3ya", error: error.message });
  }
};

// Generate payout positions automatically once a gam3ya is full
export const generatePayoutOrder = async (req, res) => {
  try {
    const gam3ya = await Gam3ya.findById(req.params.id);

    if (!gam3ya) {
      return res.status(404).json({ message: "Gam3ya not found" });
    }

    if (gam3ya.members.length === 0) {
      return res.status(400).json({ message: "No members to generate positions for" });
    }

    // Only allow generation when full
    if (gam3ya.members.length < gam3ya.maxMembers) {
      return res
        .status(400)
        .json({ message: "Gam3ya is not full yet. Cannot generate payout order." });
    }

    // Check if already generated
    const existingPositions = await Position.countDocuments({ gam3yaId: gam3ya._id });
    if (existingPositions > 0) {
      return res.status(400).json({ message: "Payout order already generated for this Gam3ya" });
    }

    // Ensure startDate is set
    if (!gam3ya.startDate) {
      gam3ya.startDate = new Date();
      await gam3ya.save();
    }

    // Remove existing positions for this gam3ya to avoid duplicates
    await Position.deleteMany({ gam3yaId: gam3ya._id });

    // Generate positions with random order (or based on member order)
    const shuffled = [...gam3ya.members].sort(() => Math.random() - 0.5);
    const positionsToCreate = shuffled.map((memberId, index) => ({
      gam3yaId: gam3ya._id,
      userId: memberId,
      positionNumber: index + 1,
    }));

    const createdPositions = await Position.insertMany(positionsToCreate);

    // Generate payment schedule
    const paymentSchedule = [];
    const startDate = new Date(gam3ya.startDate);
    
    for (let i = 0; i < gam3ya.maxMembers; i++) {
      const paymentDate = new Date(startDate);
      paymentDate.setMonth(paymentDate.getMonth() + i);
      
      const deadline = new Date(paymentDate);
      deadline.setDate(deadline.getDate() + 7); // 7 days after payment date

      paymentSchedule.push({
        round: i + 1,
        positionNumber: i + 1,
        paymentDate,
        deadline,
        status: "pending",
      });
    }

    // Update gam3ya with payment schedule and status
    gam3ya.paymentSchedule = paymentSchedule;
    gam3ya.status = "ongoing";
    await gam3ya.save();

    res.status(201).json({
      message: "Payout order generated",
      positions: createdPositions,
      paymentSchedule,
    });
  } catch (error) {
    res.status(500).json({ message: "Failed to generate payout order", error: error.message });
  }
};

