import TradeRequest from "../models/TradeRequest.js";
import Position from "../models/Position.js";
import Gam3ya from "../models/Gam3ya.js";
import Notification from "../models/Notification.js";
import User from "../models/User.js";

// Helper: Check if user can trade (24-hour restriction)
async function canUserTrade(userId, gam3yaId) {
  const gam3ya = await Gam3ya.findById(gam3yaId).populate("paymentSchedule");
  if (!gam3ya || !gam3ya.paymentSchedule || gam3ya.paymentSchedule.length === 0) {
    return { allowed: true };
  }

  const userPosition = await Position.findOne({ userId, gam3yaId });
  if (!userPosition) {
    return { allowed: true }; // No position = no deadline restriction
  }

  const now = new Date();
  const userSchedule = gam3ya.paymentSchedule.find(
    (s) => s.positionNumber === userPosition.positionNumber
  );

  if (!userSchedule || !userSchedule.deadline) {
    return { allowed: true };
  }

  const deadline = new Date(userSchedule.deadline);
  const hoursUntilDeadline = (deadline - now) / (1000 * 60 * 60);

  if (hoursUntilDeadline <= 24 && hoursUntilDeadline > 0) {
    return {
      allowed: false,
      message: "You cannot trade positions within 24 hours of your payment deadline.",
    };
  }

  return { allowed: true };
}

// Helper: Check if user is member of Gam3ya
async function isMember(userId, gam3yaId) {
  const gam3ya = await Gam3ya.findById(gam3yaId);
  if (!gam3ya) return false;
  return gam3ya.members.some((m) => m.toString() === userId.toString());
}

// Create a trade request
export const createTradeRequest = async (req, res) => {
  try {
    const { requesterId, targetPositionId, offeredAmount, notes } = req.body;

    if (!requesterId || !targetPositionId) {
      return res.status(400).json({ message: "requesterId and targetPositionId are required" });
    }

    const targetPosition = await Position.findById(targetPositionId)
      .populate("gam3yaId")
      .populate("userId", "username email");

    if (!targetPosition) {
      return res.status(404).json({ message: "Target position not found" });
    }

    // Check membership
    const isRequesterMember = await isMember(requesterId, targetPosition.gam3yaId._id);
    if (!isRequesterMember) {
      return res.status(403).json({
        message: "You are not a member of this Gam3ya. Please join it first.",
      });
    }

    // Check 24-hour restriction
    const tradeCheck = await canUserTrade(requesterId, targetPosition.gam3yaId._id);
    if (!tradeCheck.allowed) {
      return res.status(400).json({ message: tradeCheck.message });
    }

    // Get requester's position
    const requesterPosition = await Position.findOne({
      userId: requesterId,
      gam3yaId: targetPosition.gam3yaId._id,
    });

    if (!requesterPosition) {
      return res.status(400).json({ message: "You don't have a position in this Gam3ya" });
    }

    // Check if already has pending request
    const existingRequest = await TradeRequest.findOne({
      requesterId,
      targetPositionId,
      status: "pending",
    });

    if (existingRequest) {
      return res.status(400).json({ message: "You already have a pending trade request for this position" });
    }

    // Create trade request
    const tradeRequest = await TradeRequest.create({
      requesterId,
      targetPositionId,
      requesterPositionId: requesterPosition._id,
      offeredAmount: offeredAmount || 0,
      notes,
      gam3yaId: targetPosition.gam3yaId._id,
      status: "pending",
    });

    // Create notification for position owner
    await Notification.create({
      userId: targetPosition.userId._id || targetPosition.userId,
      type: "trade_request_received",
      title: "New Trade Request",
      message: `${requesterPosition.userId?.username || "A user"} wants to trade positions with you in ${targetPosition.gam3yaId.name}`,
      relatedGam3yaId: targetPosition.gam3yaId._id,
      relatedPositionId: targetPositionId,
      relatedTradeRequestId: tradeRequest._id,
      metadata: {
        requesterId,
        offeredAmount,
      },
    });

    const populated = await TradeRequest.findById(tradeRequest._id)
      .populate("requesterId", "username email")
      .populate("targetPositionId")
      .populate("requesterPositionId");

    res.status(201).json({
      message: "Trade request created",
      tradeRequest: populated,
    });
  } catch (error) {
    res.status(500).json({ message: "Failed to create trade request", error: error.message });
  }
};

// Accept a trade request
export const acceptTradeRequest = async (req, res) => {
  try {
    const { requestId, userId } = req.body;

    if (!requestId || !userId) {
      return res.status(400).json({ message: "requestId and userId are required" });
    }

    const tradeRequest = await TradeRequest.findById(requestId)
      .populate("targetPositionId")
      .populate("requesterPositionId")
      .populate("gam3yaId");

    if (!tradeRequest) {
      return res.status(404).json({ message: "Trade request not found" });
    }

    if (tradeRequest.status !== "pending") {
      return res.status(400).json({ message: "Trade request is not pending" });
    }

    const targetPosition = await Position.findById(tradeRequest.targetPositionId._id)
      .populate("userId", "username email")
      .populate("gam3yaId");

    // Verify user owns the target position
    const ownerId = targetPosition.userId._id?.toString() || targetPosition.userId.toString();
    if (ownerId !== userId.toString()) {
      return res.status(403).json({ message: "You don't own this position" });
    }

    // Check 24-hour restriction for both users
    const requesterCheck = await canUserTrade(tradeRequest.requesterId, tradeRequest.gam3yaId._id);
    if (!requesterCheck.allowed) {
      return res.status(400).json({ message: requesterCheck.message });
    }

    const ownerCheck = await canUserTrade(userId, tradeRequest.gam3yaId._id);
    if (!ownerCheck.allowed) {
      return res.status(400).json({ message: ownerCheck.message });
    }

    const requesterPosition = await Position.findById(tradeRequest.requesterPositionId._id)
      .populate("userId", "username email");

    // Swap positions
    const tempUserId = targetPosition.userId._id || targetPosition.userId;
    targetPosition.userId = requesterPosition.userId._id || requesterPosition.userId;
    requesterPosition.userId = tempUserId;

    // Update trade history
    targetPosition.tradeHistory.push({
      type: "traded",
      fromUser: tempUserId,
      toUser: requesterPosition.userId._id || requesterPosition.userId,
      timestamp: new Date(),
      note: `Traded via request. Offered amount: ${tradeRequest.offeredAmount || 0} EGP`,
    });

    requesterPosition.tradeHistory.push({
      type: "traded",
      fromUser: requesterPosition.userId._id || requesterPosition.userId,
      toUser: tempUserId,
      timestamp: new Date(),
      note: `Traded via request. Offered amount: ${tradeRequest.offeredAmount || 0} EGP`,
    });

    await targetPosition.save();
    await requesterPosition.save();

    // Update trade request status
    tradeRequest.status = "accepted";
    await tradeRequest.save();

    // Create notifications
    await Notification.create({
      userId: tradeRequest.requesterId,
      type: "trade_request_accepted",
      title: "Trade Request Accepted",
      message: `Your trade request for position #${targetPosition.positionNumber} in ${tradeRequest.gam3yaId.name} has been accepted`,
      relatedGam3yaId: tradeRequest.gam3yaId._id,
      relatedPositionId: targetPosition._id,
      relatedTradeRequestId: requestId,
    });

    await Notification.create({
      userId: userId,
      type: "trade_request_accepted",
      title: "Trade Completed",
      message: `You accepted the trade request. Positions have been swapped.`,
      relatedGam3yaId: tradeRequest.gam3yaId._id,
      relatedPositionId: requesterPosition._id,
      relatedTradeRequestId: requestId,
    });

    res.status(200).json({
      message: "Trade request accepted. Positions swapped.",
      tradeRequest,
      positions: {
        target: targetPosition,
        requester: requesterPosition,
      },
    });
  } catch (error) {
    res.status(500).json({ message: "Failed to accept trade request", error: error.message });
  }
};

// Reject a trade request
export const rejectTradeRequest = async (req, res) => {
  try {
    const { requestId, userId } = req.body;

    if (!requestId || !userId) {
      return res.status(400).json({ message: "requestId and userId are required" });
    }

    const tradeRequest = await TradeRequest.findById(requestId)
      .populate("targetPositionId")
      .populate("gam3yaId");

    if (!tradeRequest) {
      return res.status(404).json({ message: "Trade request not found" });
    }

    if (tradeRequest.status !== "pending") {
      return res.status(400).json({ message: "Trade request is not pending" });
    }

    const targetPosition = await Position.findById(tradeRequest.targetPositionId._id)
      .populate("userId");

    const ownerId = targetPosition.userId._id?.toString() || targetPosition.userId.toString();
    if (ownerId !== userId.toString()) {
      return res.status(403).json({ message: "You don't own this position" });
    }

    tradeRequest.status = "rejected";
    await tradeRequest.save();

    // Create notification
    await Notification.create({
      userId: tradeRequest.requesterId,
      type: "trade_request_rejected",
      title: "Trade Request Rejected",
      message: `Your trade request for position #${targetPosition.positionNumber} in ${tradeRequest.gam3yaId.name} has been rejected`,
      relatedGam3yaId: tradeRequest.gam3yaId._id,
      relatedPositionId: targetPosition._id,
      relatedTradeRequestId: requestId,
    });

    res.status(200).json({
      message: "Trade request rejected",
      tradeRequest,
    });
  } catch (error) {
    res.status(500).json({ message: "Failed to reject trade request", error: error.message });
  }
};

// Get trade requests for a user
export const getTradeRequests = async (req, res) => {
  try {
    const { userId, type } = req.query; // type: 'sent' or 'received'

    if (!userId) {
      return res.status(400).json({ message: "userId is required" });
    }

    let query = {};
    if (type === "sent") {
      query = { requesterId: userId };
    } else if (type === "received") {
      const userPositions = await Position.find({ userId });
      const positionIds = userPositions.map((p) => p._id);
      query = { targetPositionId: { $in: positionIds }, status: "pending" };
    } else {
      // Get both sent and received
      const userPositions = await Position.find({ userId });
      const positionIds = userPositions.map((p) => p._id);
      query = {
        $or: [{ requesterId: userId }, { targetPositionId: { $in: positionIds } }],
      };
    }

    const requests = await TradeRequest.find(query)
      .populate("requesterId", "username email")
      .populate("targetPositionId")
      .populate("requesterPositionId")
      .populate("gam3yaId", "name")
      .sort({ createdAt: -1 });

    res.status(200).json({ tradeRequests: requests });
  } catch (error) {
    res.status(500).json({ message: "Failed to fetch trade requests", error: error.message });
  }
};

