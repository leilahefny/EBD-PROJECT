# Gama3li Shokran – MERN Application

Full-stack rotating savings (Gam3ya) platform with a payout position marketplace, built as the final deliverable for the EBD course.

## 1. Features (Milestone 3)

- **User Authentication**: Register and log in with email + password. Passwords are securely **hashed using bcrypt** on the server.
- **Create & Join Gam3ya**: Users can create new Gam3ya groups and join existing ones until `maxMembers` is reached.
- **Automatic Payout Order**: Once a Gam3ya is full, the payout order is generated automatically and stored as `Position` documents.
- **Monthly Payment Tracking**: Each payout position has a simple `paidThisMonth` flag, which users can mark as paid from the dashboard.
- **Position Marketplace**: Positions can be listed for trade, bought by another member, or swapped between two members.

All frontend pages use **live data from the Express API** (no hardcoded mock data in the UI).

## 2. Tech Stack

- **Frontend**: React + Vite (in `client/`), React Router, fetch API.
- **Backend**: Node.js, Express, MongoDB, Mongoose, bcrypt, cors, morgan.

## 3. Running the Project Locally

### 3.1 Backend (Express API)

```bash
cd server
npm install

# copy and adjust environment variables if needed
copy env.sample .env   # on Windows CMD

npm run dev            # or: npm start
```

The API will run on `http://localhost:5000` by default.

### 3.2 Frontend (React + Vite)

```bash
cd client
npm install

# Optional: configure API base URL
# echo VITE_API_URL=http://localhost:5000 > .env.local

npm run dev
```

The SPA will be available at `http://localhost:5173` (Vite default).

## 4. Main API Endpoints (Summary)

- `POST /api/users/register` – Register a new user (password hashed).
- `POST /api/users/login` – Log in and return basic user info.
- `GET /api/gam3ya` – List all Gam3ya groups.
- `POST /api/gam3ya` – Create a new Gam3ya.
- `POST /api/gam3ya/:id/join` – Join a Gam3ya as a member.
- `POST /api/gam3ya/:id/generate-positions` – Generate payout positions when full.
- `GET /api/positions` – List all positions.
- `GET /api/positions/trade` – List positions currently offered for trade.
- `POST /api/positions/:id/list` – Mark a position as available for trade.
- `POST /api/positions/:id/buy` – Transfer a position to another user.
- `POST /api/positions/:id/pay` – Mark the monthly payment as paid.
- `POST /api/positions/swap` – Swap two positions between members.

## 5. Frontend Pages & Use Cases

- `/login` & `/register` – **User Authentication** flows.
- `/gam3yas` – Create & join Gam3yas, trigger automatic payout order.
- `/dashboard` – View your positions, mark monthly payments as paid.
- `/positions` – Browse tradeable positions, list your position, and buy positions.
- `/` – Landing page summarizing features and linking into the app.

This repository now contains the complete **Milestone 0–3** implementation with a working MERN stack and documented setup steps.
