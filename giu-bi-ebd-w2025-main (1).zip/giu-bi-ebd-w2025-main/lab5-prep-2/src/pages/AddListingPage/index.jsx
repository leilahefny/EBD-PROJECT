function AddListingPage() {
  return <h1>Add listing page</h1>;
}

export default AddListingPage;
