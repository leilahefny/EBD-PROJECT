function NotFoundPage() {
  return <h1>Not found page</h1>;
}

export default NotFoundPage;
