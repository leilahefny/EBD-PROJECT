const score = 35
if (score > 50) console.log("Pass")
else console.log("Fail")
const status = score > 50 ? "Good" : "Needs work"
console.log(status)

for (let i = 1; i <= 5; i++) console.log(i)

let i = 5;
while (i > 0) {
    console.log(i)
    i--;
}