// Activity: printing to the console and making use of variables
const movieTitle = "Fight Club"
const releaseYear = 1999
const watchedRecently = true

const person = {
    name: "Jane Doe",
    age: 22,
    city: "New York"
}

console.log(`My favorite movie is ${movieTitle}. It was released in ${releaseYear}. Watched recently: ${watchedRecently}.`)

console.table(person)