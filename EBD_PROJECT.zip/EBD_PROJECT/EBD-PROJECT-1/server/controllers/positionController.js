import Position from "../models/Position.js";

export const createPosition = async (req, res) => {
  try {
    const position = await Position.create(req.body);
    res.status(201).json({ message: "Position created", position });
  } catch (error) {
    res.status(500).json({ message: "Failed to create position", error: error.message });
  }
};

export const getPositions = async (_req, res) => {
  try {
    const positions = await Position.find().populate("gam3yaId").populate("userId", "username email");
    res.status(200).json({ positions });
  } catch (error) {
    res.status(500).json({ message: "Failed to fetch positions", error: error.message });
  }
};

export const getPositionById = async (req, res) => {
  try {
    const position = await Position.findById(req.params.id)
      .populate("gam3yaId")
      .populate("userId", "username email");
    if (!position) {
      return res.status(404).json({ message: "Position not found" });
    }
    res.status(200).json({ position });
  } catch (error) {
    res.status(500).json({ message: "Failed to fetch position", error: error.message });
  }
};

export const updatePosition = async (req, res) => {
  try {
    const position = await Position.findByIdAndUpdate(req.params.id, req.body, {
      new: true,
      runValidators: true,
    });
    if (!position) {
      return res.status(404).json({ message: "Position not found" });
    }
    res.status(200).json({ message: "Position updated", position });
  } catch (error) {
    res.status(500).json({ message: "Failed to update position", error: error.message });
  }
};

export const deletePosition = async (req, res) => {
  try {
    const position = await Position.findByIdAndDelete(req.params.id);
    if (!position) {
      return res.status(404).json({ message: "Position not found" });
    }
    res.status(200).json({ message: "Position deleted" });
  } catch (error) {
    res.status(500).json({ message: "Failed to delete position", error: error.message });
  }
};

export const listPositionsForTrade = async (_req, res) => {
  try {
    const positions = await Position.find({ isForTrade: true })
      .populate("gam3yaId")
      .populate("userId", "username email");
    res.status(200).json({ positions });
  } catch (error) {
    res.status(500).json({ message: "Failed to list positions for trade", error: error.message });
  }
};

export const listPositionForTrade = async (req, res) => {
  try {
    const position = await Position.findByIdAndUpdate(
      req.params.id,
      { isForTrade: true },
      { new: true }
    );
    if (!position) {
      return res.status(404).json({ message: "Position not found" });
    }
    res.status(200).json({ message: "Position listed for trade", position });
  } catch (error) {
    res.status(500).json({ message: "Failed to list position", error: error.message });
  }
};

export const buyOrSwapPosition = async (req, res) => {
  try {
    const { newUserId } = req.body;
    const position = await Position.findById(req.params.id);

    if (!position) {
      return res.status(404).json({ message: "Position not found" });
    }

    position.userId = newUserId;
    position.isForTrade = false;
    await position.save();

    res.status(200).json({ message: "Position purchased/swapped", position });
  } catch (error) {
    res.status(500).json({ message: "Failed to buy/swap position", error: error.message });
  }
};

